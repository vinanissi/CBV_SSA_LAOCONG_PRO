import type { TaskDetail, TaskItem } from '@/api/contracts';
import type { WorkInboxFocusItem } from '@/modules/task/types/workInboxTypes';
import { WORK_INBOX_STATUS_CHIP } from '../components/WorkInboxStatusChip';
import {
  buildTaskChecklistFieldBag,
  resolveSchemaFieldValue,
  resolveTaskHeaderBlocks,
} from './resolveTaskChecklistFieldValues';
import { TASK_HEADER_SCHEMA } from './taskChecklistInformationModelSchemas';

function focusPriorityLabel(priority?: string): string {
  if (!priority) return '—';
  const map: Record<string, string> = {
    low: 'Thấp',
    normal: 'Bình thường',
    high: 'Cao',
    critical: 'Khẩn cấp',
  };
  return map[priority ?? ''] ?? priority ?? '—';
}

interface CompactTaskHeaderProps {
  item: WorkInboxFocusItem;
  assignee: string;
  dueLabel: string;
  runtimeTask?: TaskItem;
  taskDetail?: TaskDetail | null;
  aiSummaryText?: string;
}

export function CompactTaskHeader({
  item,
  assignee,
  dueLabel,
  runtimeTask,
  taskDetail = null,
  aiSummaryText,
}: CompactTaskHeaderProps) {
  const statusConfig = WORK_INBOX_STATUS_CHIP[item.status] ?? WORK_INBOX_STATUS_CHIP.unknown;
  const slaWarn = item.status === 'overdue';
  const bag = buildTaskChecklistFieldBag({ item, runtimeTask, taskDetail, aiSummaryText });
  const title =
    resolveSchemaFieldValue(TASK_HEADER_SCHEMA[0], bag) ?? item.title?.trim() ?? '—';
  const bodyBlocks = resolveTaskHeaderBlocks(bag);
  const aiFromSchema = resolveSchemaFieldValue(
    TASK_HEADER_SCHEMA.find((f) => f.key === 'task_ai_summary')!,
    bag,
  );
  const showAiInHeader = Boolean(aiFromSchema);

  return (
    <header
      className="work-inbox-compact-task-header"
      data-cbv-panel="work-inbox-compact-task-header"
      data-cbv-task-checklist-model="v1"
    >
      <h2 className="work-inbox-compact-task-header__title">{title}</h2>

      {bodyBlocks.length > 0 ? (
        <dl className="work-inbox-compact-task-header__fields">
          {bodyBlocks.map((block) => (
            <div key={block.key} className="work-inbox-compact-task-header__field">
              <dt>{block.label}:</dt>
              <dd>{block.value}</dd>
            </div>
          ))}
        </dl>
      ) : null}

      <div className="work-inbox-compact-task-header__badges">
        <span
          className={`work-inbox-compact-task-header__pill work-inbox-compact-task-header__pill--status work-inbox-compact-task-header__pill--${item.status}`}
        >
          {statusConfig.label}
        </span>
        <span
          className={
            slaWarn
              ? 'work-inbox-compact-task-header__pill work-inbox-compact-task-header__pill--sla-warn'
              : 'work-inbox-compact-task-header__pill work-inbox-compact-task-header__pill--sla-ok'
          }
        >
          SLA: {slaWarn ? 'Cảnh báo' : 'OK'}
        </span>
        {item.priority ? (
          <span className="work-inbox-compact-task-header__pill work-inbox-compact-task-header__pill--priority">
            Ưu tiên: {focusPriorityLabel(item.priority)}
          </span>
        ) : null}
      </div>

      <p className="work-inbox-compact-task-header__meta">
        <span className="work-inbox-compact-task-header__meta-item">
          <span className="work-inbox-compact-task-header__meta-label">Phụ trách</span> {assignee}
        </span>
        <span className="work-inbox-compact-task-header__sep" aria-hidden>
          ·
        </span>
        <span className="work-inbox-compact-task-header__meta-item">
          <span className="work-inbox-compact-task-header__meta-label">Hạn</span> {dueLabel}
        </span>
      </p>

      {showAiInHeader ? (
        <p className="work-inbox-compact-task-header__ai" aria-label="AI tóm tắt">
          <span className="work-inbox-compact-task-header__meta-label">AI tóm tắt:</span>{' '}
          {aiFromSchema}
        </p>
      ) : null}
    </header>
  );
}

export function taskHeaderShowsAiSummary(aiSummaryText?: string): boolean {
  return Boolean(aiSummaryText?.trim());
}
