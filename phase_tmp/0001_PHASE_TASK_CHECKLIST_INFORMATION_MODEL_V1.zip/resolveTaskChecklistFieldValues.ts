import type { TaskDetail, TaskItem } from '@/api/contracts';
import type { WorkInboxFocusItem } from '@/modules/task/types/workInboxTypes';
import { WORK_INBOX_STATUS_CHIP } from '../components/WorkInboxStatusChip';
import {
  OPERATOR_DETAIL_PANEL_SCHEMA,
  TASK_HEADER_SCHEMA,
  type TaskChecklistFieldSchema,
} from './taskChecklistInformationModelSchemas';

export type TaskChecklistFieldBag = Record<string, string | undefined>;

function focusPriorityLabel(priority?: string): string {
  if (!priority) return '—';
  const map: Record<string, string> = {
    low: 'Thấp',
    normal: 'Bình thường',
    high: 'Cao',
    critical: 'Khẩn cấp',
    LOW: 'Thấp',
    NORMAL: 'Bình thường',
    HIGH: 'Cao',
    CRITICAL: 'Khẩn cấp',
  };
  return map[priority] ?? priority;
}

const MODULE_LABEL_VI: Record<string, string> = {
  TASK: 'Công việc',
  HO_SO: 'Hồ sơ',
  FINANCE: 'Tài chính',
  DOCS: 'Tài liệu',
  INVOICE: 'Hóa đơn',
};

function formatModuleLabel(module?: string): string {
  const key = module?.trim().toUpperCase();
  if (!key) return 'Công việc';
  return MODULE_LABEL_VI[key] ?? module ?? 'Công việc';
}

function resolveUnitLabel(runtimeTask?: TaskItem, taskDetail?: TaskDetail | null): string {
  const related = runtimeTask?.relatedEntityType?.trim() || taskDetail?.relatedEntityType?.trim();
  if (related && related !== 'GENERAL') return related.replace(/_/g, ' ');
  return '';
}

function firstNonEmpty(...values: (string | undefined | null)[]): string | undefined {
  for (const v of values) {
    const t = v?.trim();
    if (t) return t;
  }
  return undefined;
}

export function buildTaskChecklistFieldBag(options: {
  item: WorkInboxFocusItem;
  runtimeTask?: TaskItem;
  taskDetail?: TaskDetail | null;
  aiSummaryText?: string;
}): TaskChecklistFieldBag {
  const { item, runtimeTask, taskDetail, aiSummaryText } = options;
  const statusConfig = WORK_INBOX_STATUS_CHIP[item.status] ?? WORK_INBOX_STATUS_CHIP.unknown;
  const assignee =
    item.assigneeName?.trim() ||
    taskDetail?.displayAssigneeName?.trim() ||
    runtimeTask?.displayAssigneeName?.trim() ||
    '';
  const slaOk = item.status !== 'overdue';
  const description = taskDetail?.description?.trim();
  const title = item.title?.trim() || taskDetail?.title?.trim() || runtimeTask?.title?.trim();

  const contextParts = [
    taskDetail?.pendingAction?.trim(),
    taskDetail?.blockReason?.trim(),
    item.summary?.trim(),
  ].filter(Boolean);

  return {
    task_title: title,
    task_detail_description: description,
    task_description: description,
    task_pending_action: taskDetail?.pendingAction?.trim(),
    task_block_reason: taskDetail?.blockReason?.trim(),
    task_summary: item.summary?.trim(),
    task_context: contextParts.length > 0 ? contextParts.join(' · ') : undefined,
    task_expected_result: taskDetail?.nextStep?.trim(),
    task_next_step: taskDetail?.nextStep?.trim(),
    task_ai_summary: aiSummaryText?.trim(),
    task_owner: assignee || undefined,
    task_status_label: statusConfig.label,
    task_priority_label: focusPriorityLabel(item.priority ?? runtimeTask?.priority),
    task_due_state: item.dueLabel?.trim() || undefined,
    task_sla_state: slaOk ? 'OK' : 'Cảnh báo',
    task_queue_progress: `${item.progressIndex} / ${item.progressTotal}`,
    task_related_dossier: runtimeTask?.relatedHoSoId?.trim()
      ? 'Có — xem tab Hồ sơ'
      : 'Xem tab Hồ sơ',
    task_unit: resolveUnitLabel(runtimeTask, taskDetail) || undefined,
    task_module_label: formatModuleLabel(runtimeTask?.module ?? item.module),
  };
}

export function resolveSchemaFieldValue(
  field: TaskChecklistFieldSchema,
  bag: TaskChecklistFieldBag,
): string | undefined {
  const primary = bag[field.source]?.trim();
  if (primary) return primary;
  for (const fb of field.fallbackSources ?? []) {
    const v = bag[fb]?.trim();
    if (v) return v;
  }
  return undefined;
}

export interface ResolvedSchemaRow {
  key: string;
  label: string;
  value: string;
}

export function resolveSchemaRows(
  schema: TaskChecklistFieldSchema[],
  bag: TaskChecklistFieldBag,
): ResolvedSchemaRow[] {
  const sorted = [...schema].sort((a, b) => a.order - b.order);
  const rows: ResolvedSchemaRow[] = [];

  for (const field of sorted) {
    const raw = resolveSchemaFieldValue(field, bag);
    if (!raw) {
      if (field.showWhenEmpty && field.emptyPlaceholder) {
        rows.push({ key: field.key, label: field.label, value: field.emptyPlaceholder });
      }
      continue;
    }
    if (field.key === 'task_description' && raw === bag.task_title) continue;
    rows.push({ key: field.key, label: field.label, value: raw });
  }

  return rows;
}

export function resolveTaskHeaderBlocks(
  bag: TaskChecklistFieldBag,
): { key: string; label: string; value: string }[] {
  return resolveSchemaRows(
    TASK_HEADER_SCHEMA.filter((f) => f.key !== 'task_title' && f.key !== 'task_ai_summary'),
    bag,
  );
}

export function resolveOperatorDetailSummaryRows(bag: TaskChecklistFieldBag): ResolvedSchemaRow[] {
  return resolveSchemaRows(OPERATOR_DETAIL_PANEL_SCHEMA, bag);
}
