﻿# PHASE_BUNDLE_INDEX
phase: PHASE_TASK_RELATED_ENTITY_INPUT_MODEL_V1
result: GO_WITH_WARNINGS
files: 10
warnings: legacy description parse; browser deferred
